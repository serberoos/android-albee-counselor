package com.example.capstone_counselor;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ListDateActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_date);
    }
}