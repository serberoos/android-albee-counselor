package com.example.capstone_counselor;

public class ItemData
{
    public String strTitle;
    public String strDate;
}


